from utils import extract_text_sections, embed_text, compute_similarity
